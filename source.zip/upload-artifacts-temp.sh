S3URI="s3://ee-assets-prod-us-east-1/modules/2cae1f20008d4fc5aaef294602649b98/v8/"

aws s3 cp source.zip $S3URI/source.zip
aws s3 cp cloud9-ide-instance.template.yaml $S3URI/cloud9-ide-instance.template.yaml
aws s3 cp bootstrap.sh $S3URI/bootstrap.sh
aws s3 sync functions $S3URI/functions/
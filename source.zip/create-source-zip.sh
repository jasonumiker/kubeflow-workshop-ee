rm source.zip
zip -r source.zip . -x '*.git*' -x '*cdk.out*' -x '*.vscode*'